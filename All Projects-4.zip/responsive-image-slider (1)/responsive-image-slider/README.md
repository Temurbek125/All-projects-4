# Responsive Image Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/dfitzy/pen/xZqGVo](https://codepen.io/dfitzy/pen/xZqGVo).

A basic responsive image slider featuring next/previous buttons with a bullet based sub-navigation created with a bit of jQuery. Icons created by Robin Kylander at http://www.flaticon.com/authors/robin-kylander from www.flaticon.com. Licensed under CC By 3.0