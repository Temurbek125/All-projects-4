# Playlist Carousel - css only

A Pen created on CodePen.io. Original URL: [https://codepen.io/aybukeceylan/pen/RwrRPoO](https://codepen.io/aybukeceylan/pen/RwrRPoO).

Design by: Mauricio Bucardo 
https://dribbble.com/shots/6584163-Playlist-Carousel